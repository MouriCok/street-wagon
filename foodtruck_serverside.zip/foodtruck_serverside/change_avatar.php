<?php
require_once 'database.php';

// Check if the request contains the necessary parameters
if (isset($_POST['playerId']) && isset($_FILES['avatar'])) {
    // Sanitize the input to prevent SQL injection
    $playerId = mysqli_real_escape_string($conn, $_POST['playerId']);

    // Handle file upload
    $uploadDirectory = 'uploads/';

    // Ensure the 'uploads' directory exists
    if (!is_dir($uploadDirectory)) {
        mkdir($uploadDirectory, 0777, true);
    }

    $avatarTempPath = $_FILES['avatar']['tmp_name'];
    $avatarFileName = basename($_FILES['avatar']['name']);
    $avatarPath = $uploadDirectory . $avatarFileName;

    // Move the uploaded file to the specified directory
    if (move_uploaded_file($avatarTempPath, $avatarPath)) {
        // Perform the update operation
        $editQuery = "UPDATE user SET avatar = '$avatarPath' WHERE id = $playerId";

        if (mysqli_query($conn, $editQuery)) {
            // Send a response indicating success
            echo json_encode(['status' => 'success']);
        } else {
            // Send a response indicating failure
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
    } else {
        // Send a response indicating file upload failure
        echo json_encode(['status' => 'error', 'message' => 'Error uploading file.']);
    }
} else {
    // Send a response indicating invalid request
    echo json_encode(['status' => 'error', 'message' => 'Invalid request. Please provide valid image file.']);
}

// Close the database connection
mysqli_close($conn);
?>

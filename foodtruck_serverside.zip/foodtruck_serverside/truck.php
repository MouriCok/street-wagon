<?php
session_start();
require_once 'database.php';
$conn = mysqli_connect("localhost", "root", "", "classicmodels");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo "<script>";
    echo "if (confirm('Sorry for the inconvenience. You need to LOG INTO YOUR ACCOUNT first before making any update. Do you want to go to the login page?')) {";
    echo "  window.location.href='login.php';";
    echo "} else {";
    echo "  history.back();";
    echo "}";
    echo "</script>";
    exit;
}

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Query player data
    $sql = "SELECT * FROM user WHERE username='$username'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
    } else {
        // Handle the case when the query fails
        $name = "";
        $email = "";
        $phone = "";
    }
} else {
    // If not logged in, set default values or handle the case as needed
    $name = "";
    $email = "";
    $phone = "";
}

if (isset($_POST['submit'])) {
    // Retrieve other form data
    $ftname = $_POST['ftname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $dayClose = $_POST['dayClose'];
    $timeOpen = $_POST['timeOpen'];
    $timeClose = $_POST['timeClose'];
    $countryCode = $_POST['country_code']; // Add this line to get the selected country code

    // Insert the booking information into the database
    $sql = "INSERT INTO foodtruck (ftname, email, phone, latitude, longitude, dayClose, timeOpen, timeClose, country_code) VALUES ('$ftname', '$email', '$countryCode$phone', '$latitude', '$longitude', '$dayClose', '$timeOpen', '$timeClose', '$countryCode')";

    if (mysqli_query($conn, $sql)) {
      echo "<script>";
      echo "alert('New Food Truck is added!\\nPress OK to continue.');";
      echo "window.location.href = 'profile.php';";
      echo "</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title>Food Truck Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Anton&family=League+Spartan:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="stylee.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #0a9778;
      background-size: auto;
      background-position: center;
      background-attachment: scroll;
      margin: 0;
      padding: 0;
      align-items: center;
      justify-content: center;
      height: 86vh;
    }

    .login-container {
      background-color: #eed9c4;
      border-radius: 8px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
      padding: 20px;
      width: 700px;
      text-align: center;
      display: flex;
      flex-direction: column;
    }

    .login-container h2 {
      font-family: 'League Spartan', sans-serif;
      margin-bottom: 20px;
      color: #FA9A54;
      text-shadow: 1px 2px 2px #626262;
    }
    p4 {
      font-family: 'League Spartan', sans-serif;
      margin-bottom: 20px;
      font-size: 25px;
      color: #FA9A54;
      text-shadow: 1px 2px 2px #626262;
    }

    .form-group {
      position: relative;
      margin-bottom: 15px;
    }

    .form-group label {
      margin-bottom: 10px;
      display: block;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      box-sizing: border-box;
    }

    .form-group input[type="radio"] {
      margin-right: 5px; /* Add margin between radio buttons */
    }

    .login-container input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    .date {
      width: 40% !important;
    }

    .login-container label {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #bcbcbc;
      font-size: 14px;
      pointer-events: none;
      transition: top 0.3s, font-size 0.3s;
    }

    .login-container input:focus + label,
    .login-container input:valid + label {
      top: 10px;
      font-size: 12px;
      color: #82c87e;
    }

    .login-container button {
      background-color: #027f65;
      color: #fff;
      padding: 10px;
      border: none;
      width: 40%;
      border-radius: 4px;
      cursor: pointer;
    }

    .login-container a {
      color: #4caf50;
      text-decoration: none;
      margin-left: 5px;
    }

    .page-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin: 0;
      padding: 0;
      min-height: 100vh;
    }
    .radio-columns {
      display: flex;
    }
    .radio-column {
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    .radio-column span {
      width: 10px;
      margin-left: 50px;
      font-size: 18px;
      display: flex;
      font-family: 'League Spartan', sans-serif;
    }
    .radio-column input {
      margin-right: 5px;
    }
    .reserve {
      display: flex;
    }
    .column-1 {
      flex: 1;
    }
    .phone-input-container {
      display: flex;
      margin-bottom: 15px;
    }

    .country-code-select {
      width: 25%; /* Adjust the width as needed */
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .phone-input {
      width: 75%; /* Adjust the width as needed */
    }
  </style>
  <script>
    function goBack(event) {
      event.preventDefault();
      window.history.back();
    }
  </script>
</head>
<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
      <img src="SW_icon_tp.png" width="40" height="40">  
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="javascript:void(0);" onclick="goBack(event);"> BACK</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="page-container">
    <div class="login-container">
      <h2>ADD FOOD TRUCK</h2>
        <form method="post" action="truck.php" class="form booking">
          <div class="reserve">
            <div class="column-1">
              <div class="form-group">
                <input type="text" id="ftname" name="ftname" required>
                <label for="ftname">Name</label>
              </div>
              <div class="form-group">
                <input type="email" id="email" name="email" required>
                <label for="email">Email</label>
              </div>
              Phone :<br>
              <div class="form-group phone-input-container">
                <select class="country-code-select" name="country_code">
                  <option value="+60">+60</option>
                  <!-- <option value="+44">+44</option> -->
                </select>
                <input type="text" id="phone" name="phone" class="phone-input" required>
              </div>
              <div class="form-group">
                Choose Open Time:<br>
                <input class="time" type="time" id="timeOpen" name="timeOpen" required><br>
              </div>
            </div>
            <div class="column-1">
              <div class="form-group">
                <input type="text" id="latitude" name="latitude" required>
                <label for="latitude">Latitude</label>
              </div>
              <div class="form-group">
                <input type="text" id="longitude" name="longitude" required>
                <label for="longitude">Longitude</label>
              </div>
              <div class="form-group">
                Day Close:
                <input type="text" id="dayClose" name="dayClose" required>
              </div>
              <div class="form-group">
                Choose Close Time:<br>
                <input class="time" type="time" id="timeClose" name="timeClose" required>
              </div>
            </div>
          </div>
          
          <button type="submit" name="submit" class="submitBtn btn btn-default">ADD NEW FOOD TRUCK</button>
        </form>
    </div>
  </div>

  <footer class="container-fluid text-center">
  <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right">
      <li>
        <h5 >Open-source Apache Licensed</h5>
      </li>
    </ul>
  </div>
</footer>
	</body>
</html>

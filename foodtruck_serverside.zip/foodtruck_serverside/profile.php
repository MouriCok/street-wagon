<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("location: login.php");
    exit;
}

$conn = mysqli_connect("localhost", "root", "", "classicmodels");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username = $_SESSION['username'];
$sql = "SELECT * FROM user WHERE username='$username'";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $rows = mysqli_fetch_assoc($result);

        if (isset($_GET["logout"])) {
            unset($_SESSION['logged_in']);
            unset($_SESSION['username']);
            session_destroy();
            header("Location: index.php");
            exit();
        }
    } else {
        die("No user found for username: $username");
    }
} else {
    die("Error in SQL query: " . mysqli_error($conn));
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="stylee.css">
  <style>
    body {
        color: #1a202c;
        text-align: left;
        background-color: #0a9778;
    }
    .container {
      margin-top: 34px;
      margin-bottom: -34px;
      min-height: 85vh;
    }
    .main-body {
        padding: 15px;
    }
    h6 {
      font-weight: bold;
    }
    .card {
        box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
    }

    .card {
        position: relative;
        display: flex;
        flex-direction: column;
        min-width: 0;
        word-wrap: break-word;
        background-color: #fff;
        background-clip: border-box;
        border: 0 solid rgba(0,0,0,.125);
        border-radius: .45rem;
    }

    .card-body {
        flex: 1 1 auto;
        min-height: 1px;
        padding: 1rem;
    }
    .list-group {
      margin-top: 15px;
    }

    .gutters-sm {
        margin-right: -8px;
        margin-left: -8px;
    }

    .gutters-sm>.col, .gutters-sm>[class*=col-] {
        padding-right: 8px;
        padding-left: 8px;
    }
    .mb-0 {
      margin-top: 0px !important;
    }
    .mb-3, .my-3 {
        margin-bottom: 2rem!important;
    }

    .bg-gray-300 {
        background-color: #e2e8f0;
    }
    .h-100 {
        height: 100%!important;
    }
    .shadow-none {
        box-shadow: none!important;
    }
    .active {
      color: darkblue !important;
    }
  </style>
  <script>
    function goBack(event) {
      event.preventDefault();
      window.history.back();
    }
  </script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
    <img src="SW_icon_tp.png" width="40" height="40" alt="Logo">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php"> HOME</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
    <div class="main-body">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <form action="#" method="get">
                    <input type="submit" class='btn btn-danger btn-sm' name="logout" value="Logout">
                  </form>
                </li>
                <li class="breadcrumb-item active" aria-current="page"><a href="profile.php" class='btn btn-primary btn-sm'>Admin Profile</a></li>
                <li class="breadcrumb-item" aria-current="page"><a href="truck.php" class='btn btn-info btn-sm'>Add Food Truck</a></li>
                <li class="breadcrumb-item" aria-current="page"><a href="menu.php" class='btn btn-info btn-sm'>Add Menu</a></li>
            </ol>
        </nav>
          <!-- /Breadcrumb -->

          <!-- Profile Picture section -->
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <?php
                      $conn = mysqli_connect("localhost", "root", "", "classicmodels");

                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }

                      $username = $rows['username'];
                      $playerQuery = "SELECT id, avatar FROM user WHERE username = '$username'";
                      $playerResult = mysqli_query($conn, $playerQuery);
                      if ($playerResult) {
                        if (mysqli_num_rows($playerResult) > 0) {
                            while ($playerRow = mysqli_fetch_assoc($playerResult)) {
                              if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
                                // If user is logged in, check if they have a custom avatar
                                if ($playerRow['avatar'] !== null) {
                                    // If user has a custom avatar, display it
                                    echo "<img src='" . $playerRow['avatar'] . "' alt='user' class='rounded-circle' width='140'>";
                                } else {
                                    // If user has no custom avatar, display the default avatar
                                    echo "<img src='profile.png' alt='default_avatar' class='rounded-circle' width='140'>";
                                }
                              } else {
                                  // If user is not logged in, display the default avatar
                                  echo "<img src='profile.png' alt='default_avatar' class='rounded-circle' width='140'>";
                              }
                              echo "<br><br>";
                              echo "<button class='btn btn-primary btn-sm' onclick='changeProfile(" . $playerRow['id'] . ")'>Change</button> ";
                            }
                        } else {
                            echo "<tr><td colspan='3'>No database found.</td></tr>";
                        }
                      } else {
                          die("Error in user query: " . mysqli_error($conn));
                      }
                      mysqli_close($conn);
                    ?>
                    <script>
                      function changeProfile(playerId) {
                        var fileInput = document.createElement("input");
                        fileInput.type = "file";
                        fileInput.accept = "image/*"; // Allow only image files

                        // Trigger click event on the file input to open the file selection dialog
                        fileInput.click();

                        // Listen for the file selection change event
                        fileInput.addEventListener("change", function () {
                          var selectedFile = fileInput.files[0];

                          // Check if a file is selected
                          if (selectedFile) {
                            // Display the file name (optional)
                            console.log("Selected File: " + selectedFile.name);

                            // Call the function to submit the form with the selected file
                            submitEditAvatar(playerId, selectedFile);
                          } else {
                            // User canceled file selection
                            console.log("File selection canceled");
                          }
                        });
                      }

                      function submitEditAvatar(playerId, selectedFile) {
                        // Use FormData to handle file uploads
                        var formData = new FormData();

                        // Append player ID and selected file to the FormData object
                        formData.append("playerId", playerId);
                        formData.append("avatar", selectedFile);

                        // Use XMLHttpRequest to send the FormData to the server
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "change_avatar.php", true);

                        // Define a callback function to handle the server's response
                        xhr.onreadystatechange = function () {
                          if (xhr.readyState === 4 && xhr.status === 200) {
                            // Handle the response from the server (if needed)
                            console.log(xhr.responseText);
                          }
                        };

                        // Send the FormData to the server
                        xhr.send(formData);
                      }
                    </script>
                    <div class="mt-3">
                      <?php
                          $conn = mysqli_connect("localhost", "root", "", "classicmodels");

                          if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                          }

                          $username = $rows['username'];
                          $playerQuery = "SELECT id, name, username FROM user WHERE username = '$username'";
                          $playerResult = mysqli_query($conn, $playerQuery);
                          if ($playerResult) {
                            if (mysqli_num_rows($playerResult) > 0) {
                                while ($playerRow = mysqli_fetch_assoc($playerResult)) {
                                  echo "<h5><strong>" . $playerRow['name'] . "</strong></h5>";
                                  echo "<h6>" . $playerRow['username'] . "</h6>";
                                }
                            } else {
                                echo "<tr><td colspan='3'>No database found.</td></tr>";
                            }
                        } else {
                            die("Error in user query: " . mysqli_error($conn));
                        }
                        mysqli_close($conn);
                      ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!--Admin Profile section-->
              <div class="col-md-8">
                      <div class="card col-sm-12 mb-3">
                        <div class="h-100">
                          <div class="card-body">
                            <h5 class="card-title">Admin Profile</h5>
                            <table class="table table-striped">
                              <tbody>
                                <?php
                                  $conn = mysqli_connect("localhost", "root", "", "classicmodels");

                                  if (!$conn) {
                                    die("Connection failed: " . mysqli_connect_error());
                                  }

                                  $username = $rows['username'];
                                  $playerQuery = "SELECT id, name, username, email, phone FROM user WHERE username = '$username'";
                                  $playerResult = mysqli_query($conn, $playerQuery);

                                  if ($playerResult) {
                                      if (mysqli_num_rows($playerResult) > 0) {
                                          while ($playerRow = mysqli_fetch_assoc($playerResult)) {
                                              echo "<tr>";
                                              echo "<th>Full Name</th>";
                                              echo "<td>" . $playerRow['name'] . "</td>";
                                              echo "</tr>";
                                              echo "<tr>";
                                              echo "<th>Username</th>";
                                              echo "<td>" . $playerRow['username'] . "</td>";
                                              echo "</tr>";
                                              echo "<tr>";
                                              echo "<th>Email</th>";
                                              echo "<td>" . $playerRow['email'] . "</td>";
                                              echo "</tr>";
                                              echo "<tr>";
                                              echo "<th>Mobile</th>";
                                              echo "<td>" . $playerRow['phone'] . "</td>";
                                              echo "</tr>";
                                              echo "<tr>";
                                              echo "<th>";
                                              echo "<button class='btn btn-primary btn-sm' onclick='editProfile(" . $playerRow['id'] . ")'>Edit</button> ";
                                              echo "</th>";
                                              echo "<td></td>";
                                              echo "</tr>";
                                          }
                                      } else {
                                          echo "<tr><td colspan='3'>No database found.</td></tr>";
                                      }
                                  } else {
                                      die("Error in user query: " . mysqli_error($conn));
                                  }
                                  mysqli_close($conn);
                                ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                    <script>
                      function editProfile(playerId) {
                        var editName = prompt("Enter new Full Name:");
                        var editEmail = prompt("Enter new Email");
                        var editPhone = prompt("Enter new Phone Number:");

                        if (editName !== null && editEmail !== null && editPhone !== null) {
                          submitEditForm(playerId, editName, editEmail, editPhone);
                        }
                      }

                      function submitEditForm(playerId, editName, editEmail, editPhone) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "edit_profile.php";

                        var inputId = document.createElement("input");
                        inputId.type = "hidden";
                        inputId.name = "playerId";
                        inputId.value = playerId;

                        var inputName = document.createElement("input");
                        inputName.type = "hidden";
                        inputName.name = "name";
                        inputName.value = editName;

                        var inputEmail = document.createElement("input");
                        inputEmail.type = "hidden";
                        inputEmail.name = "email";
                        inputEmail.value = editEmail;

                        var inputPhone = document.createElement("input");
                        inputPhone.type = "hidden";
                        inputPhone.name = "phone";
                        inputPhone.value = editPhone;

                        form.appendChild(inputId);
                        form.appendChild(inputName);
                        form.appendChild(inputEmail);
                        form.appendChild(inputPhone);

                        document.body.appendChild(form);
                        
                        form.submit();
                      }
                    </script>

                    <!--Food Truck section-->
                    <div class="col-md-16">
                      <div class="card col-sm-12 mb-3">
                        <div class="h-100">
                          <div class="card-body">
                            <h5 class="card-title">Food Truck</h5>
                            <table class="table table-striped">
                              <thead>
                                <tr>
                                  <th>Food Truck</th>
                                  <th>Email</th>
                                  <th>Phone</th>
                                  <th>Latitude</th>
                                  <th>Longitude</th>
                                  <th>Day Close</th>
                                  <th>Time Open</th>
                                  <th>Time Close</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php
                                  $conn = mysqli_connect("localhost", "root", "", "classicmodels");

                                  if (!$conn) {
                                    die("Connection failed: " . mysqli_connect_error());
                                  }

                                  $foodtruckQuery = "SELECT * FROM foodtruck";
                                  $foodtruckResult = mysqli_query($conn, $foodtruckQuery);

                                  if ($foodtruckResult) {
                                      if (mysqli_num_rows($foodtruckResult) > 0) {
                                          while ($foodtruckRow = mysqli_fetch_assoc($foodtruckResult)) {
                                              echo "<tr>";
                                              echo "<td>" . $foodtruckRow['ftname'] . "</td>";
                                              echo "<td>" . $foodtruckRow['email'] . "</td>";
                                              echo "<td>" . $foodtruckRow['phone'] . "</td>";
                                              echo "<td>" . $foodtruckRow['latitude'] . "</td>";
                                              echo "<td>" . $foodtruckRow['longitude'] . "</td>";
                                              echo "<td>" . $foodtruckRow['dayClose'] . "</td>";
                                              echo "<td>" . $foodtruckRow['timeOpen'] . "</td>";
                                              echo "<td>" . $foodtruckRow['timeClose'] . "</td>";
                                              echo "<td>";
                                              echo "<button class='btn btn-primary btn-sm' onclick='updateTruck(" . $foodtruckRow['foodtruckId'] . ")'>Update</button> ";
                                              echo "<button class='btn btn-danger btn-sm' onclick='deleteTruck(" . $foodtruckRow['foodtruckId'] . ")'>Delete</button>";
                                              echo "</td>";
                                              echo "</tr>";
                                          }
                                      } else {
                                          echo "<tr><td colspan='3'>No Food Truck found.</td></tr>";
                                      }
                                  } else {
                                      die("Error in foodtruck query: " . mysqli_error($conn));
                                  }

                                  mysqli_close($conn);
                                ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                    <script>
                      function updateTruck(foodtruckId) {
                        var updatedName = prompt("Enter new Name: \n[Street Wagon]");
                        var updatedEmail = prompt("Enter new Email: \n[streetwagon@example.com]");
                        var updatedPhone = prompt("Enter new Phone: \n[121231234]");
                        var updatedLat = prompt("Enter new Latitude: \n[Arau]");
                        var updatedLong = prompt("Enter new Longitude: \n[Arau]");
                        var updatedDayClose = prompt("Enter new Close Day: \n[Sunday]");
                        var updatedTimeOpen = prompt("Enter new Open Time:\n[HH:MM:SS]");
                        var updatedTimeClose = prompt("Enter new Close Time:\n[HH:MM:SS]");

                        if (updatedName !== null && updatedEmail !== null && updatedPhone !== null && updatedLat !== null && updatedLong !== null && updatedDayClose !== null && updatedTimeOpen !== null && updatedTimeClose !== null) {
                          submitUpdateForm(foodtruckId, updatedName, updatedEmail, updatedPhone, updatedLat, updatedLong, updatedDayClose, updatedTimeOpen, updatedTimeClose);
                        }
                      }

                      function submitUpdateForm(foodtruckId, updatedName, updatedEmail, updatedPhone, updatedLat, updatedLong, updatedDayClose, updatedTimeOpen, updatedTimeClose) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "update_truck.php";

                        var inputId = document.createElement("input");
                        inputId.type = "hidden";
                        inputId.name = "foodtruckId";
                        inputId.value = foodtruckId;

                        var inputName = document.createElement("input");
                        inputName.type = "hidden";
                        inputName.name = "ftname";
                        inputName.value = updatedName;

                        var inputEmail = document.createElement("input");
                        inputEmail.type = "hidden";
                        inputEmail.name = "email";
                        inputEmail.value = updatedEmail;

                        var inputPhone = document.createElement("input");
                        inputPhone.type = "hidden";
                        inputPhone.name = "phone";
                        inputPhone.value = updatedPhone;

                        var inputLat = document.createElement("input");
                        inputLat.type = "hidden";
                        inputLat.name = "latitude";
                        inputLat.value = updatedLat;

                        var inputLong = document.createElement("input");
                        inputLong.type = "hidden";
                        inputLong.name = "longitude";
                        inputLong.value = updatedLong;

                        var inputDayClose = document.createElement("input");
                        inputDayClose.type = "hidden";
                        inputDayClose.name = "dayClose";
                        inputDayClose.value = updatedDayClose;

                        var inputTimeOpen = document.createElement("input");
                        inputTimeOpen.type = "hidden";
                        inputTimeOpen.name = "timeOpen";
                        inputTimeOpen.value = updatedTimeOpen;

                        var inputTimeClose = document.createElement("input");
                        inputTimeClose.type = "hidden";
                        inputTimeClose.name = "timeClose";
                        inputTimeClose.value = updatedTimeClose;

                        form.appendChild(inputId);
                        form.appendChild(inputName);
                        form.appendChild(inputEmail);
                        form.appendChild(inputPhone);
                        form.appendChild(inputLat);
                        form.appendChild(inputLong);
                        form.appendChild(inputDayClose);
                        form.appendChild(inputTimeOpen);
                        form.appendChild(inputTimeClose);

                        document.body.appendChild(form);
                        
                        form.submit();
                      }

                      function deleteTruck(foodtruckId) {
                      if (confirm("Are you sure you want to delete this Truck?")) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "delete_truck.php";

                        var input = document.createElement("input");
                        input.type = "hidden";
                        input.name = "foodtruckId";
                        input.value = foodtruckId;

                        form.appendChild(input);
                        document.body.appendChild(form);

                        form.submit();
                      }
                    }
                    </script>

                    <!--Menu Details section-->
                    <div class="col-md-16">
                      <div class="card col-sm-12 mb-3">
                        <div class="h-100">
                          <div class="card-body">
                            <h5 class="card-title">Menu Details</h5>
                            <table class="table table-striped">
                              <thead>
                                <tr>
                                  <th>Food Truck ID</th>
                                  <th>Food Truck</th>
                                  <th>Menu ID</th>
                                  <th>Menu</th>
                                  <th>Price</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php
                                $conn = mysqli_connect("localhost", "root", "", "classicmodels");

                                if (!$conn) {
                                    die("Connection failed: " . mysqli_connect_error());
                                }

                                $foodtruckQuery = "SELECT * FROM foodtruck";
                                $foodtruckResult = mysqli_query($conn, $foodtruckQuery);

                                $menuQuery = "SELECT * FROM menu";
                                $menuResult = mysqli_query($conn, $menuQuery);

                                if ($foodtruckResult && $menuResult) {
                                    if (mysqli_num_rows($foodtruckResult) > 0 && mysqli_num_rows($menuResult) > 0) {
                                        while ($foodtruckRow = mysqli_fetch_assoc($foodtruckResult)) {
                                            // Store the current foodtruckId
                                            $currentFoodtruckId = $foodtruckRow['foodtruckId'];
                                            // Reset the menu result pointer to fetch menu rows again for each foodtruck row
                                            mysqli_data_seek($menuResult, 0);
                                            while ($menuRow = mysqli_fetch_assoc($menuResult)) {
                                                if ($menuRow['foodtruckId'] == $currentFoodtruckId) { // Ensure matching foodtruckId
                                                    echo "<tr>";
                                                    echo "<td>" . $foodtruckRow['foodtruckId'] . "</td>"; // Display correct foodtruckId
                                                    echo "<td>" . $foodtruckRow['ftname'] . "</td>";
                                                    echo "<td>" . $menuRow['id'] . "</td>";
                                                    echo "<td>" . $menuRow['name'] . "</td>";
                                                    echo "<td>" . $menuRow['price'] . "</td>";
                                                    echo "<td>";
                                                    echo "<button class='btn btn-primary btn-sm' onclick='updateMenu(" . $menuRow['id'] . ")'>Update</button> ";
                                                    echo "<button class='btn btn-danger btn-sm' onclick='deleteMenu(" . $menuRow['id'] . ")'>Delete</button>";
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                            }
                                        }
                                    } else {
                                        echo "<tr><td colspan='6'>No Food Truck or Menu found.</td></tr>";
                                    }
                                } else {
                                    die("Error in query: " . mysqli_error($conn));
                                }

                                mysqli_close($conn);
                              ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                    <script>
                      function updateMenu(id) {
                        var MenuName = prompt("Enter new Menu Name: \n[Chicken Masallah]");
                        var MenuPrice = prompt("Enter new Menu Price: \n[15.90]");

                        if (MenuName !== null && MenuPrice !== null) {
                          submitUpdateMenu(id, MenuName, MenuPrice);
                        }
                      }

                      function submitUpdateMenu(id, MenuName, MenuPrice) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "update_menu.php";

                        var inputMenuId = document.createElement("input");
                        inputMenuId.type = "hidden";
                        inputMenuId.name = "id";
                        inputMenuId.value = id;

                        var inputMName = document.createElement("input");
                        inputMName.type = "hidden";
                        inputMName.name = "name";
                        inputMName.value = MenuName;

                        var inputPrice = document.createElement("input");
                        inputPrice.type = "hidden";
                        inputPrice.name = "price";
                        inputPrice.value = MenuPrice;

                        form.appendChild(inputMenuId);
                        form.appendChild(inputMName);
                        form.appendChild(inputPrice);

                        document.body.appendChild(form);
                        
                        form.submit();
                      }

                      function deleteMenu(id) {
                      if (confirm("Are you sure you want to delete this Menu?")) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "delete_menu.php";

                        var inputMenu = document.createElement("input");
                        inputMenu.type = "hidden";
                        inputMenu.name = "id";
                        inputMenu.value = id;

                        form.appendChild(inputMenu);
                        document.body.appendChild(form);

                        form.submit();
                      }
                    }
                    </script>
            </div>
          </div>
        </div>
    </div>
    <script>
      function changeProfile(playerId) {
          var input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';
          input.click();

          input.addEventListener('change', function () {
              var file = input.files[0];
              if (file) {
                  var formData = new FormData();
                  formData.append('playerId', playerId);
                  formData.append('avatar', file);

                  // Use AJAX to handle form submission
                  var xhr = new XMLHttpRequest();
                  xhr.open('POST', 'change_avatar.php', true);
                  xhr.onload = function () {
                      try {
                          var response = JSON.parse(xhr.responseText);
                          if (response.status === 'success') {
                              // Reload the page to reflect the changes
                              location.reload();
                          } else {
                              // Display an error message
                              alert('Error: ' + response.message);
                          }
                      } catch (error) {
                          console.error('Error parsing JSON response', error);
                      }
                  };

                  xhr.send(formData);
              }
          });
      }
  </script>
</body>
<footer class="container-fluid text-center">
  <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right">
      <li>
        <h5 >Open-source Apache Licensed</h5>
      </li>
    </ul>
  </div>
</footer>
</html>
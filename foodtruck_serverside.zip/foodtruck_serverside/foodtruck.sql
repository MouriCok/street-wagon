-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2024 at 12:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodtruck`
--

-- --------------------------------------------------------

--
-- Table structure for table `foodtruck`
--

CREATE TABLE `foodtruck` (
  `foodtruckId` int(11) NOT NULL,
  `ftname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `dayClose` varchar(12) NOT NULL,
  `timeOpen` time DEFAULT NULL,
  `timeClose` time DEFAULT NULL,
  `country_code` varchar(5) NOT NULL,
  `status` int(30) NOT NULL,
  `latitude` varchar(355) NOT NULL,
  `longitude` varchar(355) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodtruck`
--

INSERT INTO `foodtruck` (`foodtruckId`, `ftname`, `email`, `phone`, `dayClose`, `timeOpen`, `timeClose`, `country_code`, `status`, `latitude`, `longitude`) VALUES
(1, 'Ayamm Goreng Mukris', 'ayamgoreng@gmail.com', '0112002013', 'Monday', '06:24:08', '17:24:08', 'MY', 1, '6.449652588814972', '100.26768815392501'),
(2, 'Pizza Hut', 'pizza@gmail.com', '01193992922', 'Tuesday', '06:26:16', '17:26:16', 'MY', 1, '6.447413788023189', '100.2679134594829'),
(3, 'KFC Malay', 'kfc@gmail.com', '01123123123', 'Monday', '06:24:08', '17:24:08', 'MY', 1, '6.447925514783965', '100.26658308383782'),
(4, 'Kopi Muar', 'kopi@gmail.com', '01123123', 'Monday', '18:25:12', '05:25:12', 'MY', 1, '6.4294896622232995', '100.27077234419589');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(355) NOT NULL,
  `price` float NOT NULL,
  `foodtruckId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `price`, `foodtruckId`) VALUES
(1, 'ayam goreng', 3, 1),
(2, 'Pizza Mike', 10, 2),
(3, 'KFC Jimat box', 15, 3),
(4, 'Kepak Goreng', 5, 1),
(5, 'Kopi Viral Coklat', 15, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foodtruck`
--
ALTER TABLE `foodtruck`
  ADD PRIMARY KEY (`foodtruckId`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foodtruck`
--
ALTER TABLE `foodtruck`
  MODIFY `foodtruckId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

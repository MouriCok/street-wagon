$(document).ready(function(){
    // Smooth scroll to the facility section when clicking the FACILITY button
    $(".facility-btn").click(function() {
        $('html, body').animate({
            scrollTop: $(".container-fluid.bg-3").offset().top
        }, 1000);
    });
});

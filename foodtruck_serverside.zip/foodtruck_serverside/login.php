<?php
  session_start();
  require_once 'database.php';
  $conn = mysqli_connect("localhost", "root", "", "classicmodels");
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $conn = mysqli_connect("localhost", "root", "", "classicmodels");
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      $_SESSION['logged_in'] = true;
      $_SESSION['username'] = $username;
      header("location: profile.php");
      exit();
    } else {
      echo "<script>alert('Invalid username or password'); window.location.href = 'login.php';</script>";
    }
    mysqli_close($conn);
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title>Street Wagon Admin Login Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Anton&family=League+Spartan:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="stylee.css">
  <link rel="stylesheet" href="formm.css">
  <style>
    .page-container {
      margin: 45px;
      padding: 0;
      min-height: 50vh;
    }
    .login-container {
      padding: 20px;
      width: 450px;
      margin-top: 100px;
      margin-bottom: 88px;
    }
  </style>
  <script>
    function goBack(event) {
      event.preventDefault();
      window.history.back();
    }
  </script>
</head>
<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
      <img src="SW_icon_tp.png" width="40" height="40">  
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="javascript:void(0);" onclick="goBack(event);"> BACK</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="page-container">
    <div class="login-container">
      <h2>ADMIN LOGIN</h2>
      <form method="post" action="login.php" class="form login">
        <div class="form-group">
          <input type="text" id="username" name="username" required>
          <label for="username">Username</label>
        </div>
        <div class="form-group">
          <input type="password" id="password" name="password" required>
          <label for="password">Password</label>
        </div>
        <button type="submit" name="submit" class="submitBtn btn btn-default">LOGIN</button>
      </form>
    </div>
    <!-- End login form -->
  </div>

  <footer class="container-fluid text-center">
  <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right">
      <li>
        <h5 >Open-source Apache Licensed</h5>
      </li>
    </ul>
  </div>
</footer>
	</body>
</html>
